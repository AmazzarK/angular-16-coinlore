export const environment = {
  api: 'https://api.coinlore.net/api',
};
