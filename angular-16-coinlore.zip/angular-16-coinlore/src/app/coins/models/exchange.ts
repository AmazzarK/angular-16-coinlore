export interface Exchange {
  id: string;
  name: string;
  name_id: string;
  volume_usd: string;
  active_pairs: string;
  url: string;
  country: string;
}
